$("#form_id").submit(function(e) {
    e.preventDefault();

  // Your Code Here!
});
