$("#form1").submit(function(e) {
  e.preventDefault();

  // Your code here!
});
